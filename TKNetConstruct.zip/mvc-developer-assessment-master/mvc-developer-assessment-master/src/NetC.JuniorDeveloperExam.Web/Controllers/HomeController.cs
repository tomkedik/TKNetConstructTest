﻿using NetC.JuniorDeveloperExam.Web.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NetC.JuniorDeveloperExam.Web.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            var jsonFile = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\App_Data\\Blog-Posts.json");

            var posts = JsonConvert.DeserializeObject<BlogPosts>(jsonFile);


            return View(posts);
        }

        public ActionResult Blog(int id)
        {
            var jsonFile = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\App_Data\\Blog-Posts.json");

            var posts = JsonConvert.DeserializeObject<BlogPosts>(jsonFile);

            Post specificPost = posts.blogPosts.Find(e => e.id == id);

            return View(specificPost);
        }
    }
}