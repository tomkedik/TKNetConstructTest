﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NetC.JuniorDeveloperExam.Web.Models
{
    public class BlogPosts
    {
        public List<Post> blogPosts { get; set; }
    }
}